package com.anushka.coroutinesdemo1

class SuspendDemo {

    private fun firstFunction(){
        //some code
    }

    private suspend fun secondFunction(){
        //some code
    }
}