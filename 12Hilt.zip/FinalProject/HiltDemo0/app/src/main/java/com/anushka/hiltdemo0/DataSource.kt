package com.anushka.hiltdemo0

import android.util.Log

class DataSource {
    fun getRemoteData() {
        Log.i("MyTag", "Data downloading....")
    }
}
